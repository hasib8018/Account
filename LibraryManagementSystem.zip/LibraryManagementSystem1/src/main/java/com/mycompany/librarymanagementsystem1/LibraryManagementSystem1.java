/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.librarymanagementsystem1;

/**
 *
 * @author USER
 */
public class LibraryManagementSystem1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
